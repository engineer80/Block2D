#!/bin/bash
java -classpath ./bin block2D.Block2D conf.txt 2>log.txt