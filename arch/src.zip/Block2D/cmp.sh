#!/bin/bash
rm ./bin/block2D/*
javac -sourcepath ./src -d ./bin ./src/block2D/Block2D.java
