#!/bin/bash
java -jar block2D.jar
