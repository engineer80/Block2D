#!/bin/bash
java -classpath ./bin block2D.Configurator
