#!/bin/bash
javac -sourcepath ./src -d ./bin ./src/block2D/Configurator.java 2>log.txt
