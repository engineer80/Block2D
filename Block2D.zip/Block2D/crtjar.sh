#!/bin/bash
jar -cmef ./src/manifest.mf block2D.Block2D block2D.jar -C ./bin .
